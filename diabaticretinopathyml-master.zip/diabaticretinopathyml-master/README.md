# diabatic retinopathy ml
A web application to diagnose diabetic retinopathy disease using deep learning.

## How to Run?